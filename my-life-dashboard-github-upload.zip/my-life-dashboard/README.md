# My Life Dashboard

A dark-themed personal planner that runs in a browser and can be installed as a Progressive Web App (PWA).

## Included features
- Monthly calendar and date selection
- Daily journal
- Daily tasks
- Study planner
- Expense tracker (INR)
- Habit tracker
- Goals and progress tracking
- JSON backup and restore
- PWA manifest, service worker and app icons

## Run locally
For basic testing, open `index.html` in a browser. PWA installation and service-worker offline caching require HTTPS or localhost.

Recommended local server:
1. Open this folder in VS Code.
2. Install the "Live Server" extension.
3. Right-click `index.html` and choose "Open with Live Server".

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload all files in this folder to the repository root.
3. Open repository **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then Save.
6. Wait for the Pages URL to appear, then open it over HTTPS.

## Install
- Windows/Chrome: open the published HTTPS site and use the install icon in the address bar, or Chrome menu → Cast, save and share → Install page as app (wording can vary).
- Android/Chrome: open the same HTTPS site → three-dot menu → Install app or Add to Home screen.

## Data and privacy
This version stores entries in the browser's local storage on each device. It does **not** sync automatically between laptop and phone. Use **Backup → Download Backup** on one device and **Restore Backup** on the other to transfer data manually. Keep backup files private. Do not store highly sensitive information.

For automatic cross-device sync, add a secure sign-in and cloud database (for example Firebase) before entering personal data. Do not put private API keys or service-account credentials in this public repository.

## Updating
After changing app files, commit and push them to GitHub. If an old version remains cached, close and reopen the app or clear the site's cached data.
